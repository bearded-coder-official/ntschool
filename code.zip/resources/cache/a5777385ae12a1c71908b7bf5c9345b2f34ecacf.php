<?php $__env->startSection('content'); ?>
    <h1>Главная страница</h1>

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h2><?php echo e($post->title); ?></h2>

        <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <i><?php echo e($category->title); ?></i>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p><?php echo e($post->description); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Нет постов</p>
    <?php endif; ?>

    <?php if($posts->currentPage() != 1): ?>
        <a href="?page=1">First Page</a>
        <a href="?page=<?php echo e($posts->currentPage() - 1); ?>">Prev Page</a>
    <?php endif; ?>
    <?php for($i = 1; $i <= $total; $i++): ?>
        <a class="<?php if($i == $posts->currentPage()): ?> current <?php endif; ?>" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
    <?php endfor; ?>
    <?php if($posts->currentPage() != $total): ?>
        <a href="?page=<?php echo e($posts->currentPage() + 1); ?>">Next Page</a>
        <a href="?page=<?php echo e($total); ?>">Last Page</a>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>