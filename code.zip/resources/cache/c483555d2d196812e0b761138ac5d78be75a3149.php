<?php $__env->startSection('content'); ?>
    <h1>Посты по категориям</h1>

    <h2>Категория: <?php echo e($category->title); ?></h2>

    <?php $__empty_1 = true; $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h3><?php echo e($post->title); ?></h3>

        <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <i><?php echo e($category->title); ?></i>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p><?php echo e($post->description); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Нет постов</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>